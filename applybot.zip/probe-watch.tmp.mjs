import { chromium } from "playwright";
const EXT = "cmndpkaonfgknkjeijmhhiiodmjmekpn";
for (let i = 0; i < 18; i++) {
  const browser = await chromium.connectOverCDP("http://127.0.0.1:9222");
  try {
    const context = browser.contexts()[0];
    const worker = context.serviceWorkers().find(w => w.url().includes(EXT));
    if (worker) {
      const out = await worker.evaluate(async () => {
        const ledger = (await chrome.storage.session.get("applyBotOwnedTabs")).applyBotOwnedTabs ?? [];
        const tabs = await chrome.tabs.query({});
        return { tabs: tabs.length, leases: ledger.map(l => `${l.purpose}${l.key ? "/" + l.key : ""}#${l.tabId}@${Math.round((Date.now() - l.usedAt) / 1000)}s`) };
      }).catch(e => ({ error: String(e).slice(0, 80) }));
      console.log(new Date().toISOString().slice(11, 19), out.tabs, JSON.stringify(out.leases ?? out.error));
    } else console.log(new Date().toISOString().slice(11, 19), "no service worker");
  } finally { await browser.close(); }
  await new Promise(r => setTimeout(r, 30000));
}
