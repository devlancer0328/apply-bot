import { chromium } from "playwright";
const browser = await chromium.connectOverCDP("http://127.0.0.1:9222");
const context = browser.contexts()[0];
const EXT = "cmndpkaonfgknkjeijmhhiiodmjmekpn";
const worker = context.serviceWorkers().find(w => w.url().includes(EXT));
const out = await worker.evaluate(async () => {
  const state = await chrome.runtime.sendMessage({ type: "state" }).catch(e => ({ error: String(e) }));
  return { running: state?.running, phase: state?.phase, log: (state?.log ?? []).slice(-40).map(l => `${l.level}: ${l.message}`) };
});
console.log(JSON.stringify(out, null, 2).slice(0, 4000));
await browser.close();
