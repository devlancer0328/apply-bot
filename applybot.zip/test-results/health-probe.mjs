/** Scratch: full run log + persisted health record. */
import { chromium } from "playwright";
const browser = await chromium.connectOverCDP("http://127.0.0.1:9222");
try {
  const context = browser.contexts()[0];
  const page = await context.newPage();
  await page.goto("chrome-extension://cmndpkaonfgknkjeijmhhiiodmjmekpn/src/options.html");
  const out = await page.evaluate(async () => {
    const { stateStorage } = await import("./store.js");
    const s = await chrome.runtime.sendMessage({ type: "state" });
    const kv = await stateStorage.get(["healthState"]);
    return {
      phase: s?.phase, running: s?.running, startedAt: s?.startedAt, finishedAt: s?.finishedAt,
      health: s?.health,
      healthState: kv.healthState,
      log: (s?.log ?? []).map(e => `${new Date(e.at).toISOString().slice(11, 23)} ${e.level} ${e.message.slice(0, 160)}`),
    };
  });
  await page.close();
  console.log(JSON.stringify(out, null, 2));
} finally { await browser.close(); }
