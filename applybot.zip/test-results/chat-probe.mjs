/** Scratch: is the ChatGPT tab usable? */
import { chromium } from "playwright";
const browser = await chromium.connectOverCDP("http://127.0.0.1:9222");
try {
  const context = browser.contexts()[0];
  for (const page of context.pages()) {
    const url = page.url();
    if (!/chatgpt\.com/.test(url)) continue;
    const info = await page.evaluate(() => ({
      url: location.href,
      title: document.title,
      composer: Boolean(document.querySelector('#prompt-textarea,[contenteditable="true"]')),
      login: [...document.querySelectorAll('button,a')].map(e => e.textContent.trim()).filter(t => /log ?in|sign ?up/i.test(t)).slice(0, 4),
    })).catch(e => ({ url, error: e.message }));
    console.log(JSON.stringify(info, null, 2));
  }
} finally { await browser.close(); }
