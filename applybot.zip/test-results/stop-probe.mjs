/** Scratch: read live run state from the extension. Not part of the suite. */
import { chromium } from "playwright";

const EXT_ID = process.env.EXT_ID ?? "cmndpkaonfgknkjeijmhhiiodmjmekpn";
const browser = await chromium.connectOverCDP(process.env.ATTACH ?? "http://127.0.0.1:9222");
try {
  const context = browser.contexts()[0];
  const page = await context.newPage();
  await page.goto(`chrome-extension://${EXT_ID}/src/options.html`);
  const seen = await page.evaluate(async () => {
    const { stateStorage } = await import("./store.js");
    const state = await chrome.runtime.sendMessage({ type: "state" });
    const kv = await stateStorage.get(["schedule", "autopilotResumeAt", "lastRunSnapshot"]);
    const session = await chrome.storage.session.get(["runProgress"]);
    const alarms = await chrome.alarms.getAll();
    return {
      running: state?.running, stopping: state?.stopping, phase: state?.phase,
      startedAt: state?.startedAt, finishedAt: state?.finishedAt,
      stopReason: state?.stopReason, counts: { total: state?.total, done: state?.done, attempted: state?.attempted, submitted: state?.submitted },
      activeJobs: Object.values(state?.activeJobs ?? {}).map(j => `${j.company} ${j.stage} ${j.message}`),
      log: (state?.log ?? []).slice(-12).map(e => `${new Date(e.at).toISOString().slice(11,19)} ${e.level} ${e.message}`),
      schedule: kv.schedule, autopilotResumeAt: kv.autopilotResumeAt,
      sessionRunning: session.runProgress?.running, snapshotRunning: kv.lastRunSnapshot?.runProgress?.running,
      alarms: alarms.map(a => a.name),
      manifest: chrome.runtime.getManifest().version,
    };
  });
  await page.close();
  console.log(JSON.stringify(seen, null, 2));
} finally {
  await browser.close();
}
