/**
 * Scratch: measure the live time from pressing Stop to the run actually
 * being stopped. Forces Review-before-sending for the duration so that
 * measuring the button cannot post an application to a real employer.
 *
 *   LABEL=before WAIT_PHASES=generating,processing,applying node test-results/stop-measure.mjs
 */
import { chromium } from "playwright";
import { writeFile } from "node:fs/promises";

const EXT = "chrome-extension://cmndpkaonfgknkjeijmhhiiodmjmekpn/src/options.html";
const WAIT_PHASES = (process.env.WAIT_PHASES ?? "extracting,screening,generating,processing,applying").split(",");
const WAIT_MAX = Number(process.env.WAIT_MAX ?? 600000);
const STOP_MAX = Number(process.env.STOP_MAX ?? 1800000);
const LABEL = process.env.LABEL ?? "run";

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const timeline = [];
const note = (what, extra = {}) => { const row = { t: Date.now(), what, ...extra }; timeline.push(row); console.log(`${new Date(row.t).toISOString().slice(11, 23)}  ${what}  ${JSON.stringify(extra)}`); };

/** The options page is an extension page, so an extension reload closes it. Reopen and carry on. */
let browser = null, page = null;
async function fresh() {
  await browser?.close().catch(() => {});
  browser = await chromium.connectOverCDP("http://127.0.0.1:9222");
  page = await browser.contexts()[0].newPage();
  await page.goto(EXT);
}
async function inPage(fn, arg) {
  for (let tries = 0; ; tries++) {
    try { return await page.evaluate(fn, arg); }
    catch (error) {
      if (tries >= 4) throw error;
      note("reconnecting", { why: String(error.message).slice(0, 60) });
      await sleep(1500);
      await fresh();
    }
  }
}

const READ = async () => {
  const s = await chrome.runtime.sendMessage({ type: "state" });
  return { running: s?.running, stopping: s?.stopping, phase: s?.phase, startedAt: s?.startedAt, stopReason: s?.stopReason, attempted: s?.attempted, total: s?.total, active: Object.values(s?.activeJobs ?? {}).length, last: (s?.log ?? []).slice(-1)[0]?.message ?? "", log: (s?.log ?? []).map((e) => ({ at: e.at, level: e.level, message: e.message })) };
};
const read = () => inPage(READ);

await fresh();
const before = await inPage(async () => {
  const { readProfile, writeProfile, stateStorage } = await import("./store.js");
  const p = await readProfile();
  await writeProfile({ dryRun: true });
  // A standing "writer signed out" from earlier today would end the run in
  // milliseconds, which measures nothing.
  const healthState = (await stateStorage.get("healthState")).healthState;
  if (healthState) await stateStorage.set({ healthState: { ...healthState, conditions: [] } });
  return { dryRun: p.dryRun, schedule: (await stateStorage.get("schedule")).schedule ?? null };
});
note("forced review mode", { dryRun: before.dryRun });

try {
  const was = await read();
  await inPage(() => chrome.runtime.sendMessage({ type: "run" }));
  note("run requested");
  const startedWaiting = Date.now();
  let seen = await read();
  while (Date.now() - startedWaiting < WAIT_MAX && !WAIT_PHASES.includes(seen.phase)) {
    await sleep(1000);
    seen = await read();
    if (seen.startedAt !== was.startedAt && !seen.running) { note("run ended before reaching a working phase", seen); break; }
  }
  note("phase reached", seen);
  if (!seen.running) throw new Error(`run never got going: ${JSON.stringify(seen)}`);

  const pressed = Date.now();
  const answer = await inPage(() => chrome.runtime.sendMessage({ type: "stop" }));
  note("STOP pressed", { answer });

  let stoppedAt = 0, uiHonestAt = 0;
  while (Date.now() - pressed < STOP_MAX) {
    const now = await read();
    if (!uiHonestAt && (now.phase === "stopping" || now.stopping === true)) { uiHonestAt = Date.now(); note("UI reflects stopping", now); }
    if (!now.running) { stoppedAt = Date.now(); note("STOPPED", now); break; }
    if (now.startedAt !== seen.startedAt || now.phase === "interrupted") { note("WORKER RESTARTED - measurement void", { phase: now.phase, stopReason: now.stopReason }); break; }
    if ((Date.now() - pressed) % 15000 < 1200) note("still running", { secs: Math.round((Date.now() - pressed) / 1000), phase: now.phase, active: now.active, last: now.last.slice(0, 90) });
    await sleep(1000);
  }
  const final = await read();
  const line = (re) => final.log?.find((e) => re.test(e.message))?.at ?? 0;
  const result = { label: LABEL, pressedAt: pressed, stopToStoppedMs: stoppedAt ? stoppedAt - pressed : null, stopToUiHonestMs: uiHonestAt ? uiHonestAt - pressed : null, logStopAt: line(/you pressed Stop|Stop requested/), logFinishedAt: line(/^Finished: /), final, timeline };
  if (result.logStopAt && result.logFinishedAt) console.log(`log-derived stop -> finished: ${((result.logFinishedAt - result.logStopAt) / 1000).toFixed(1)}s`);
  await writeFile(`test-results/stop-measure-${LABEL}.json`, JSON.stringify(result, null, 2));
  console.log(`\n=== ${LABEL}: stop -> stopped ${result.stopToStoppedMs === null ? `NOT STOPPED within ${STOP_MAX}ms` : `${(result.stopToStoppedMs / 1000).toFixed(1)}s`}; stop -> UI honest ${result.stopToUiHonestMs === null ? "never" : `${(result.stopToUiHonestMs / 1000).toFixed(1)}s`}`);
} finally {
  await inPage(async ({ dryRun, schedule }) => {
    const { writeProfile, stateStorage } = await import("./store.js");
    await writeProfile({ dryRun });
    if (schedule) await stateStorage.set({ schedule });
    await chrome.runtime.sendMessage({ type: "schedule" }).catch(() => {});
  }, before).catch(() => {});
  note("restored settings", { dryRun: before.dryRun, autopilot: before.schedule?.autopilot });
  await page?.close().catch(() => {});
  await browser?.close().catch(() => {});
}
