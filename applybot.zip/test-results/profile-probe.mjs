/** Scratch: what would a run actually do right now? */
import { chromium } from "playwright";
const browser = await chromium.connectOverCDP("http://127.0.0.1:9222");
try {
  const context = browser.contexts()[0];
  const page = await context.newPage();
  await page.goto("chrome-extension://cmndpkaonfgknkjeijmhhiiodmjmekpn/src/options.html");
  console.log(JSON.stringify(await page.evaluate(async () => {
    const { readProfile, allLinks, allPairings, allJobs } = await import("./store.js");
    const p = await readProfile();
    const jobs = await allJobs();
    return {
      dryRun: p.dryRun, autoFetch: p.autoFetch, keepRunning: p.keepRunning,
      maxPerRun: p.maxPerRun, maxSubmittedPerRun: p.maxSubmittedPerRun,
      jobrightRecommend: p.jobrightRecommend, hiringCafeUrl: p.hiringCafeUrl, boardRoster: p.boardRoster,
      chatGptProjectUrl: p.chatGptProjectUrl, chatGptConcurrency: p.chatGptConcurrency,
      links: (await allLinks()).links.length, pairings: (await allPairings()).length,
      jobStages: jobs.reduce((o, j) => ({ ...o, [j.stage]: (o[j.stage] || 0) + 1 }), {}),
    };
  }), null, 2));
  await page.close();
} finally { await browser.close(); }
