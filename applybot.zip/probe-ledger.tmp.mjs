import { chromium } from "playwright";
const browser = await chromium.connectOverCDP("http://127.0.0.1:9222");
const context = browser.contexts()[0];
const EXT = "cmndpkaonfgknkjeijmhhiiodmjmekpn";
const worker = context.serviceWorkers().find(w => w.url().includes(EXT));
console.log("service worker:", worker ? worker.url() : "none");
const out = await worker.evaluate(async () => {
  const ledger = (await chrome.storage.session.get("applyBotOwnedTabs")).applyBotOwnedTabs ?? [];
  const tabs = await chrome.tabs.query({});
  return {
    tabs: tabs.length,
    ledger: ledger.map(l => ({ tabId: l.tabId, purpose: l.purpose, key: l.key ?? "", gen: l.generation, ageS: Math.round((Date.now() - l.usedAt) / 1000) })),
    reapIsWired: typeof chrome !== "undefined",
  };
});
console.log(JSON.stringify(out, null, 2));
await browser.close();
